from pymongo import MongoClient 
from bson.objectid import ObjectId 

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, username, password): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # Connection Variables 
        # 
        USER = 'aacuser' 
        PASS = 'Snhu2026' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'aac' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient(
            f'mongodb://{username}:{password}@{HOST}:{PORT}/?authSource=admin')
        
        self.database = self.client[DB] 
        self.collection = self.database[COL] 

    # Create a method to return the next available record number for use in the create method
            
    # Complete this create method to implement the C in CRUD. 
    def create(self, data):
        if data is not None:
            
            try:
                result = self.database.animals.insert_one(data)  # data should be dictionary
                return result.acknowledged
            except Exception as e:
                print("Insert failed:", e)
                return False
            
        else:
            return False 

    # Create method to implement the R in CRUD.
    def read(self, query):
        if query is not None:
            
            try:
                cursor = self.database.animals.find(query)
                return list(cursor)
            except Exception as e:
                print("Read failed:", e)
                return []
            
        else:
            return []
        
    def update(self, query, new_values):
        """ Update documents matching query """
        
        if query is None or new_values is None:
            return 0
        
        result = self.collection.update_one(
            query,
            {"$set": new_values}
        )
        return result.modified_count
    
    def delete(self, query):
        """ Delete documents matching query """
        
        if query is None:
            return 0
        
        result = self.collection.delete_one(query)
        return result.deleted_count
    