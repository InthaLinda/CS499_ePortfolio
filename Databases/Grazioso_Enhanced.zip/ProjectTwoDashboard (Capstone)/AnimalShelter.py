import os
from pymongo import MongoClient, errors


class AnimalShelter(object):
    """CRUD operations and rescue-filter queries for the MongoDB animals collection."""

    def __init__(
        self,
        username=None,
        password=None,
        host=None,
        port=None,
        db_name=None,
        collection_name=None,
        auth_source=None
    ):
        """
        Initialize the MongoDB connection.

        Environment variables are used first so credentials are not hard-coded
        in the source code. Optional arguments are still supported for Codio or
        local testing environments.
        """
        self.username = username or os.getenv("AAC_USERNAME")
        self.password = password or os.getenv("AAC_PASSWORD")
        self.host = host or os.getenv("AAC_HOST", "localhost")
        self.port = int(port or os.getenv("AAC_PORT", 27017))
        self.db_name = db_name or os.getenv("AAC_DB", "aac")
        self.collection_name = collection_name or os.getenv("AAC_COLLECTION", "animals")
        self.auth_source = auth_source or os.getenv("AAC_AUTH_SOURCE", "admin")

        if not self.username or not self.password:
            raise ValueError(
                "MongoDB username and password are required. "
                "Set AAC_USERNAME and AAC_PASSWORD environment variables "
                "or pass credentials when creating AnimalShelter."
            )

        try:
            self.client = MongoClient(
                host=self.host,
                port=self.port,
                username=self.username,
                password=self.password,
                authSource=self.auth_source,
                serverSelectionTimeoutMS=5000
            )

            # Force a server call so authentication/connection issues appear early.
            self.client.admin.command("ping")

            self.database = self.client[self.db_name]
            self.collection = self.database[self.collection_name]
        except errors.PyMongoError as error:
            raise ConnectionError(f"MongoDB connection failed: {error}") from error

    def create_indexes(self):
        """
        Create indexes for fields commonly used in dashboard filtering.

        These indexes support the rescue-type filters and improve query
        performance as the collection grows.
        """
        try:
            self.collection.create_index("breed")
            self.collection.create_index("sex_upon_outcome")
            self.collection.create_index("age_upon_outcome_in_weeks")
            self.collection.create_index("animal_type")
            return True
        except errors.PyMongoError as error:
            print("Index creation failed:", error)
            return False

    def create(self, data):
        """Insert one animal record into the collection."""
        if not isinstance(data, dict) or not data:
            print("Create failed: data must be a non-empty dictionary.")
            return False

        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except errors.PyMongoError as error:
            print("Insert failed:", error)
            return False

    def read(self, query=None):
        """Read animal records from the collection using a MongoDB query."""
        if query is None:
            query = {}

        if not isinstance(query, dict):
            print("Read failed: query must be a dictionary.")
            return []

        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except errors.PyMongoError as error:
            print("Read failed:", error)
            return []

    def update(self, query, new_values):
        """Update one document matching the query."""
        if not isinstance(query, dict) or not query:
            print("Update failed: query must be a non-empty dictionary.")
            return 0

        if not isinstance(new_values, dict) or not new_values:
            print("Update failed: new_values must be a non-empty dictionary.")
            return 0

        try:
            result = self.collection.update_one(query, {"$set": new_values})
            return result.modified_count
        except errors.PyMongoError as error:
            print("Update failed:", error)
            return 0

    def delete(self, query):
        """Delete one document matching the query."""
        if not isinstance(query, dict) or not query:
            print("Delete failed: query must be a non-empty dictionary.")
            return 0

        try:
            result = self.collection.delete_one(query)
            return result.deleted_count
        except errors.PyMongoError as error:
            print("Delete failed:", error)
            return 0

    def build_rescue_query(self, rescue_type):
        """
        Build a MongoDB query for each rescue category.

        The query logic is centralized here instead of being repeated in the
        dashboard notebook. This improves maintainability and separation of
        concerns.
        """
        rescue_type = (rescue_type or "RESET").upper()

        rescue_queries = {
            "WATER": {
                "animal_type": "Dog",
                "breed": {"$regex": "Labrador|Chesapeake|Newfoundland", "$options": "i"},
                "sex_upon_outcome": {"$regex": "Intact Female", "$options": "i"},
                "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}
            },
            "MOUNTAIN": {
                "animal_type": "Dog",
                "breed": {"$regex": "German Shepherd|Alaskan|Old English|Siberian|Rottweiler", "$options": "i"},
                "sex_upon_outcome": {"$regex": "Intact Male", "$options": "i"},
                "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}
            },
            "DISASTER": {
                "animal_type": "Dog",
                "breed": {"$regex": "Doberman|German Shepherd|Golden Retriever|Bloodhound|Rottweiler", "$options": "i"},
                "sex_upon_outcome": {"$regex": "Intact Male", "$options": "i"},
                "age_upon_outcome_in_weeks": {"$gte": 20, "$lte": 300}
            }
        }

        return rescue_queries.get(rescue_type, {})

    def read_by_rescue_type(self, rescue_type):
        """Return animal records matching one of the dashboard rescue filters."""
        query = self.build_rescue_query(rescue_type)
        return self.read(query)

    def close(self):
        """Close the MongoDB client connection."""
        if hasattr(self, "client"):
            self.client.close()
