from AnimalShelter import AnimalShelter

def main():
    username = "aacuser"
    password = "Snhu2026"

    db = AnimalShelter(username, password)

    results = db.read({})

    if len(results) > 0:
        print("Connection and read successful.")
        print("Number of records returned:", len(results))
        print("First record:")
        print(results[0])
    else:
        print("No records returned.")
        print("This may mean authentication failed, the database is empty, or MongoDB is using a different authentication source.")

if __name__ == "__main__":
    main()