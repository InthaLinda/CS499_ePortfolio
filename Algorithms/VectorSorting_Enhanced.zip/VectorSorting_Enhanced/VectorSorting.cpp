//============================================================================
// Name        : VectorSorting.cpp
// Author      : Linda Inthavongsa
// Version     : 1.0
// Copyright   : Copyright � 2023 SNHU COCE
// Description : Vector Sorting Algorithms
//============================================================================

#include <algorithm>
#include <iostream>
#include <chrono>
#include <limits>
#include <vector>
#include <string>

#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// forward declarations
double strToDouble(string str, char ch);

// define a structure to hold bid information
struct Bid {
    string bidId; // unique identifier
    string title;
    string fund;
    double amount;
    Bid() {
        amount = 0.0;
    }
};

//============================================================================
// Static methods used for testing
//============================================================================

/**
 * Display the bid information to the console (std::out)
 *
 * @param bid struct containing the bid info
 */
void displayBid(Bid bid) {
    cout << bid.bidId << ": " << bid.title << " | " << bid.amount << " | "
        << bid.fund << endl;
    return;
}

/**
* Verify that bids have been loaded before display, sort, or search operations.
* This prevents empty-vector logic errors and provides clear user feedback.
*
*  @param bids vector containing bid records
*  @return true if records exist, false if vector is empty
*/
bool bidsLoaded(const vector<Bid>& bids) {
    if (bids.empty()) {
        cout << "Please load bids first." << endl;
        return false;
    }
    return true;
}

/**
 * Prompt user for bid information using console (std::in)
 *
 * @return Bid struct containing the bid info
 */
Bid getBid() {
    Bid bid;

    cout << "Enter Id: ";
    cin.ignore();
    getline(cin, bid.bidId);

    cout << "Enter title: ";
    getline(cin, bid.title);

    cout << "Enter fund: ";
    cin >> bid.fund;

    cout << "Enter amount: ";
    cin.ignore();
    string strAmount;
    getline(cin, strAmount);
    bid.amount = strToDouble(strAmount, '$');

    return bid;
}

/**
 * Load a CSV file containing bids into a container
 *
 * @param csvPath the path to the CSV file to load
 * @return a container holding all the bids read
 */
vector<Bid> loadBids(string csvPath) {
    cout << "Loading CSV file " << csvPath << endl;

    // Define a vector data structure to hold a collection of bids.
    vector<Bid> bids;

    // initialize the CSV Parser using the given path
    csv::Parser file = csv::Parser(csvPath);

    try {
        // loop to read rows of a CSV file
        for (int i = 0; i < file.rowCount(); i++) {

            // Create a data structure and add to the collection of bids
            Bid bid;
            bid.bidId = file[i][1];
            bid.title = file[i][0];
            bid.fund = file[i][8];
            bid.amount = strToDouble(file[i][4], '$');

            //cout << "Item: " << bid.title << ", Fund: " << bid.fund << ", Amount: " << bid.amount << endl;

            // push this bid to the end
            bids.push_back(bid);
        }
    }
    catch (csv::Error& e) {
        std::cerr << e.what() << std::endl;
    }
    return bids;
}


/**
 * Partition the vector of bids into two parts, low and high
 *
 * @param bids Address of the vector<Bid> instance to be partitioned
 * @param begin Beginning index to partition
 * @param end Ending index to partition
 */
int partition(vector<Bid>& bids, int begin, int end) {
    //set low and high equal to begin and end
    int low = begin;
    int high = end;

    // Calculate the middle element as middlePoint (int)
    int middle = begin + (end - begin) / 2;

    // Set Pivot as middlePoint element title to compare (string)
    string pivot = bids[middle].title;

    // while not done
    while (true) {

        // keep incrementing low index while bids[low].title < Pivot
        while (bids[low].title < pivot) {
            ++low;
        }

        // keep decrementing high index while Pivot < bids[high].title
        while (bids[high].title > pivot) {
            --high;
        }

        /* If there are zero or one elements remaining,
            all bids are partitioned. Return high */
        if (low >= high) {
            return high;
        }

        // else swap the low and high bids (built in vector method)
        swap(bids[low], bids[high]);
        ++low;
        --high;
    }

    // move low and high closer ++low, --high
//return high;
}

/**
 * Perform a quick sort on bid title
 * Average performance: O(n log(n))
 * Worst case performance O(n^2))
 *
 * @param bids address of the vector<Bid> instance to be sorted
 * @param begin the beginning index to sort on
 * @param end the ending index to sort on
 */
void quickSort(vector<Bid>& bids, int begin, int end) {
    //set mid equal to 0

    /* Base case: If there are 1 or zero bids to sort,
     partition is already sorted otherwise if begin is greater
     than or equal to end then return*/
    if (begin >= end) {
        return;
    }

    /* Partition bids into low and high such that
     midpoint is location of last element in low */
    int mid = partition(bids, begin, end);

    // recursively sort low partition (begin to mid)
    quickSort(bids, begin, mid);

    // recursively sort high partition (mid+1 to end)
    quickSort(bids, mid + 1, end);
}


/**
 * Perform a selection sort on bid title
 * Average performance: O(n^2))
 * Worst case performance O(n^2))
 *
 * @param bid address of the vector<Bid>
 *            instance to be sorted
 */
void selectionSort(vector<Bid>& bids) {
    //define min as int (index of the current minimum bid)

    // check size of bids vector
    // set size_t platform-neutral result equal to bid.size()
    size_t size = bids.size();

    // No sorting is needed when vector has zero or one bid.
    if (size < 2) {
        return;
    }

    // pos is the position within bids that divides sorted/unsorted
    // for size_t pos = 0 and less than size -1 
    for (size_t pos = 0; pos < size - 1; ++pos) {
        size_t min = pos;

        for (size_t i = pos + 1; i < size; ++i) {
            if (bids[i].title < bids[min].title) {
                min = i;
            }
        }
        if (min != pos) {
            swap(bids[pos], bids[min]);
        }
    }

}

/**
* Perform binary search on bid title after the vector has been sorted by title.
* Binary search improves search efficiency from linear time to O(log n).
*
* @param bids vector of sorted Bid records
* @param searchTitle title to search for
* @return index of matching bid or -1 of not found
*/
int binarySearchByTitle(const vector<Bid>& bids, const string& searchTitle) {
    int low = 0;
    int high = static_cast<int>(bids.size()) - 1;

    while (low <= high) {
        int mid = low + (high - low) / 2;

        if (bids[mid].title == searchTitle) {
            return mid;
        }
        else if (bids[mid].title < searchTitle) {
            low = mid + 1;
        }
        else {
            high = mid - 1;
        }
    }

    return -1;
}

/**
 * Simple C function to convert a string to a double
 * after stripping out unwanted char
 *
 * credit: http://stackoverflow.com/a/24875936
 *
 * @param ch The character to strip out
 */
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

/**
 * The one and only main() method
 */
int main(int argc, char* argv[]) {

    // process command line arguments
    string csvPath;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        break;
    default:
        csvPath = "eBid_Monthly_Sales.csv";
    }

    // Define a vector to hold all the bids
    vector<Bid> bids;

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Bids" << endl;
        cout << "  2. Display All Bids" << endl;
        cout << "  3. Selection Sort All Bids" << endl;
        cout << "  4. Quick Sort All Bids" << endl;
        cout << "  5. Search for Bid by Title" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {

        case 1: {
            // Initialize a high-resolution timer before loading bids
            auto start = chrono::high_resolution_clock::now();

            // Complete the method call to load the bids
            bids = loadBids(csvPath);

            auto end = chrono::high_resolution_clock::now();
            chrono::duration<double> elapsed = end - start;

            cout << bids.size() << " bids read" << endl;
            cout << "time: " << elapsed.count() << " seconds" << endl;

            break;
        }

        case 2:
            if (!bidsLoaded(bids)) {
                break;
            }

            // Loop and display the bids read
            for (int i = 0; i < bids.size(); ++i) {
                displayBid(bids[i]);
            }
            cout << endl;

            break;

        case 3: {
            if (!bidsLoaded(bids)) {
                break;
            }

            auto start = chrono::high_resolution_clock::now();

            selectionSort(bids);

            auto end = chrono::high_resolution_clock::now();
            chrono::duration<double> elapsed = end - start;

            cout << "Selection Sort completed in " << elapsed.count() << " seconds." << endl;

            break;
        }

        case 4: {
            if (!bidsLoaded(bids)) {
                break;
            }

            auto start = chrono::high_resolution_clock::now();

            quickSort(bids, 0, static_cast<int>(bids.size()) - 1);

            auto end = chrono::high_resolution_clock::now();
            chrono::duration<double> elapsed = end - start;

            cout << "Quick Sort completed in " << elapsed.count() << " seconds." << endl;

            break;
        }

        case 5: {
            if (!bidsLoaded(bids)) {
                break;
            }

            // Binary search requires sorted data, so sort by title first.
            quickSort(bids, 0, static_cast<int>(bids.size()) - 1);

            string searchTitle;
            cout << "Enter bid title to search for: ";
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            getline(cin, searchTitle);

            int result = binarySearchByTitle(bids, searchTitle);

            if (result != -1) {
                cout << "Bid found:" << endl;
                displayBid(bids[result]);
            }
            else {
                cout << "Bid not found." << endl;
            }

            break;
        }

        case 9:
            break;

        default:
            cout << "Invalid choice. Please try again." << endl;
            break;
        }
    }

    cout << "Good bye." << endl;

    return 0;
}